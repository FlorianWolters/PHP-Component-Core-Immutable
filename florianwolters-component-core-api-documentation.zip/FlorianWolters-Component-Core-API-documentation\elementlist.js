
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","BadFunctionCallException"],["c","BadMethodCallException"],["c","Exception"],["c","FlorianWolters\\Component\\Core\\ImmutableException"],["c","FlorianWolters\\Component\\Core\\ImmutableInterface"],["c","FlorianWolters\\Component\\Core\\ImmutableTrait"],["c","LogicException"]];
